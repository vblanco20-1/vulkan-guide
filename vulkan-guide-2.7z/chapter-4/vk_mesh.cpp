﻿#include <vk_mesh.h>
#include <tiny_obj_loader.h>
#include <iostream>

